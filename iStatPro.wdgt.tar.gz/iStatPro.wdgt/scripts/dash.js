

function shouldToggleImageForTab(tab) {
	if(tab == p.selectedTab)
		return false;
	return true;
}
